-- MySQL dump 10.13  Distrib 5.7.9, for Win32 (AMD64)
--
-- Host: 127.0.0.1    Database: equipage
-- ------------------------------------------------------
-- Server version	5.7.11-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users_agents`
--

DROP TABLE IF EXISTS `users_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_agents` (
  `name` varchar(60) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `natid` varchar(10) DEFAULT NULL,
  `telephone` varchar(12) DEFAULT NULL,
  `useranme` varchar(40) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `is_student` tinyint(1) DEFAULT NULL,
  `campus` varchar(40) DEFAULT NULL,
  `cv_path` varchar(100) DEFAULT NULL,
  `user_id` varchar(20) NOT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `user_photo` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_agents`
--

LOCK TABLES `users_agents` WRITE;
/*!40000 ALTER TABLE `users_agents` DISABLE KEYS */;
INSERT INTO `users_agents` VALUES ('DANIEL KIMANI','dan@gmail.com','02314567','0768234568','dan1234567','ZGFuMTIzNDU2Nw==',0,'','C:\\path\\to\\uploads\\GL2-8008510600524723562.docx','139804620','2016-04-17','22:09:44','C:\\path\\to\\uploads\\sample_image-8243756072967669289.jpg','1985-05-12'),('FRANSCIS OKUMU','franscis@fran.com','09812369','0987987509','franscis123456','ZnJhbnNjaXMxMjM0NTY=',0,NULL,'C:\\path\\to\\uploads\\GL1-2146519786837248357.docx','260849536','2016-04-14','15:01:48','C:\\path\\to\\uploads\\sample_image-2840217960648937425.jpg',NULL);
/*!40000 ALTER TABLE `users_agents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-21 23:28:13
